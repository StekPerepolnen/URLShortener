﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace URLShortener.WebAPIService.Models
{
    public class ShortUrlRequest
    {
        public string url { get; set; }
    }
}